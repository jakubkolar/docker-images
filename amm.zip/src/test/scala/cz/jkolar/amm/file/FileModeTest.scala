package cz.jkolar.amm.file

import java.nio.file.attribute.PosixFilePermission._

import org.scalatest.FlatSpec
import org.scalatest.Matchers._

class FileModeTest extends FlatSpec {

  "Convert mask to file permissions" should "recognize rwx------" in {
    // Then
    FileMode("0700").permissions should be (Set(
      OWNER_READ, OWNER_WRITE, OWNER_EXECUTE
    ))
  }

  it should "recognize standard file perms rw-r--r--" in {
    FileMode("0644").permissions should be (Set(
      OWNER_READ, OWNER_WRITE,
      GROUP_READ,
      OTHERS_READ
    ))
  }

  it should "recognize standard dir perms rwxr-xr-x" in {
    FileMode("0755").permissions should be (Set(
      OWNER_READ, OWNER_WRITE, OWNER_EXECUTE,
      GROUP_READ, GROUP_EXECUTE,
      OTHERS_READ, OTHERS_EXECUTE
    ))
  }

}
