package cz.jkolar.amm;

public enum PermissionType {
    OWNER(2), GROUP(1), OTHERS(0);

    public final int position;

    PermissionType(int position) {
        this.position = position;
    }
}


