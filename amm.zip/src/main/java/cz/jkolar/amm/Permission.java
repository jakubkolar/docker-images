package cz.jkolar.amm;

public enum Permission {
    R(4), W(2), X(1);

    public int value;

    Permission(int value) {
        this.value = value;
    }


}
