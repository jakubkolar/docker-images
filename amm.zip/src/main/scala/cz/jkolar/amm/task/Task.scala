package cz.jkolar.amm.task

import better.files.File

trait Task {

  def name: String

  def isDone(ctx: TaskExecution): Boolean

  def perform(ctx: TaskExecution): TaskResult

  def rollBack(ctx: TaskExecution): TaskResult
}





abstract class NaiveExecution[P](val params: P, val workDir: File) extends BaseExecution[P] {
  override def run(task: Task): TaskResult = {
    if (task.isDone(this)) Skipped(task) else task.perform(this)
  }
}

class NaiveLogger extends TaskLogger {
  override def debug(msg: String): Unit = {
    println("[DEBUG] " + msg)
  }

  override def info(msg: String): Unit = {
    println("[INFO] " + msg)
  }

  override def warn(msg: String): Unit = {
    println("[WARN] " + msg)
  }

  override def error(msg: String): Unit = {
    println("[ERROR] " + msg)
  }
}

trait NaiveLogging extends TaskExecution {

  abstract override def run(task: Task): TaskResult = {
    logger.info(s"Running task = $task")
    val result = super.run(task)
    logger.info(s"Task $task finished with result $result")
    result
  }

}
