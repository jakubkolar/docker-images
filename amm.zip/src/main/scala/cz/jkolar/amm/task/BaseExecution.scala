package cz.jkolar.amm.task

abstract class BaseExecution[P] extends TaskExecution {

  override def debug(msg: String): Unit = {}

  override def info(msg: String): Unit = {}

  override def warn(msg: String): Unit = {}

  override def error(msg: String): Unit = {}
}
