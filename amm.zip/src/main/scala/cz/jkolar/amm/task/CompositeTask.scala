package cz.jkolar.amm.task

import scala.collection.immutable.Seq

abstract class CompositeTask extends Task {

  def steps: Seq[Task]

  override def name: String = toString

  override def isDone(ctx: TaskExecution): Boolean = {
    steps.forall(_.isDone(ctx))
  }

  override def perform(ctx: TaskExecution): TaskResult = {
    TaskResult(this, steps.map(_.perform(ctx)))
  }

  override def rollBack(ctx: TaskExecution): TaskResult = {
    TaskResult(this, steps.reverse.map(_.rollBack(ctx)))
  }

}

object CompositeTask {
  def apply(tasks: Task*): CompositeTask = {
    new CompositeTask{
      override val steps: Seq[Task] = tasks.toVector
    }
  }
}
