package cz.jkolar.amm.task

import scala.collection.immutable.Seq
import scala.util.{Failure, Success, Try}

sealed trait TaskResult {
  def task: Task
  def subResults: Seq[TaskResult]

  override def toString: String = {
    getClass.getSimpleName + "(" + task.name +
      subResults.foldLeft(": ")((s,tr) => s + s"${tr.task.name}->${tr.getClass.getSimpleName}") +
      ")"
  }
}

object TaskResult {

  def apply(task: Task, subResults: Seq[TaskResult]): TaskResult = {
    subResults.find(_.isInstanceOf[Failed]) match {
      case Some(Failed(_, e, _)) => Failed(task, e, subResults)
      case None => Done(task, subResults.toVector)
      case _ => sys.error("Unreachable code - maybe a missing case?")
    }
  }

  implicit class TryExtension(res: Try[Any]) {
    def toTaskResult(task: Task): TaskResult = {
      res match {
        case Success(_) => Done(task)
        case Failure(e) => Failed(task, Some(e))
      }
    }
  }
}

case class Done(task: Task, subResults: Seq[TaskResult] = Seq()) extends TaskResult
case class Skipped(task: Task, subResults: Seq[TaskResult] = Seq()) extends TaskResult
case class RolledBack(task: Task, subResults: Seq[TaskResult] = Seq()) extends TaskResult
case class Failed(task: Task, e: Option[Throwable] = None, subResults: Seq[TaskResult] = Seq()) extends TaskResult
