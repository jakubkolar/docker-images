package cz.jkolar.amm.task

import better.files.File

trait TaskExecution {

  def workDir: File

  def run(task: Task): TaskResult

  def logger: TaskLogger
}

trait TaskLogger {
  def debug(msg: String): Unit
  def info(msg: String): Unit
  def warn(msg: String): Unit
  def error(msg: String): Unit
}
