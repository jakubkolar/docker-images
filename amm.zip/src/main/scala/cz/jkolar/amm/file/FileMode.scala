package cz.jkolar.amm.file

import java.nio.file.attribute.PosixFilePermission
import java.nio.file.attribute.PosixFilePermission._

import cz.jkolar.amm.Permission._
import cz.jkolar.amm.PermissionType._
import cz.jkolar.amm.file.FileMode._
import cz.jkolar.amm.{Permission, PermissionType}

case class FileMode(mask: Int) {

  def permissions: Set[PosixFilePermission] = {
    PermissionType.values().flatMap(permsFor).toSet
  }

  private def permsFor(permissionType: PermissionType): Set[PosixFilePermission] = {
    Permission.values()
      .filter(p => ((mask >> (permissionType.position*3)) & p.value) != 0)
      .map(mappings(permissionType, _))
      .toSet
  }

}

object FileMode {
  def apply(mode: String): FileMode = {
    new FileMode(Integer.parseInt(mode, 8))
  }

  private val mappings = Map(
    (OWNER, R) -> OWNER_READ,
    (OWNER, W) -> OWNER_WRITE,
    (OWNER, X) -> OWNER_EXECUTE,
    (GROUP, R) -> GROUP_READ,
    (GROUP, W) -> GROUP_WRITE,
    (GROUP, X) -> GROUP_EXECUTE,
    (OTHERS, R) -> OTHERS_READ,
    (OTHERS, W) -> OTHERS_WRITE,
    (OTHERS, X) -> OTHERS_EXECUTE
  )
}
