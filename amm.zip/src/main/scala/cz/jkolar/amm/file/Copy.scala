package cz.jkolar.amm.file

import java.nio.file.{Path, Paths}

import better.files.Dsl._
import better.files.File
import cz.jkolar.amm.TaskResult._
import cz.jkolar.amm._
import cz.jkolar.amm.file.Copy._

import scala.collection.immutable.Seq
import scala.util.Try

case class Copy(from: Path, to: Path, mode: Option[FileMode] = None) extends CompositeTask {
  override val steps: Seq[Task] = Seq(
    Some(CopyTask(from, to)),
    mode.map(ModeTask(to, _))
  ).flatten
}

object Copy {
  def apply(from: String, to: String): Copy =
    new Copy(Paths.get(from), Paths.get(to))

  def apply(from: String, to: String, mode: String): Copy =
    new Copy(Paths.get(from), Paths.get(to), Some(FileMode(mode)))

  def apply(from: String, to: String, mode: FileMode): Copy =
    new Copy(Paths.get(from), Paths.get(to), Some(mode))

  private[file] def asFile(p: Path, ctx: TaskExecution) = if (p.isAbsolute) File(p) else ctx.workDir / p.toString
}

case class CopyTask(from: Path, to: Path) extends Task {

  override def name: String = s"Copy($from -> $to)"

  override def isDone(ctx: TaskExecution): Boolean = {
    val src = asFile(from, ctx)
    val dst = asFile(to, ctx)

    if (dst.isChildOf(src)) {
      false
    } else if (src.isRegularFile && dst.isDirectory) {
      src === dst / src.name
    } else {
      src.exists && dst.exists && (src.isDirectory == dst.isDirectory) && src === dst
    }
  }

  override def perform(ctx: TaskExecution): TaskResult = {
    val src = asFile(from, ctx)
    val dst = asFile(to, ctx)
    if (dst.isChildOf(src)) {
      Failed(this, Some(new IllegalArgumentException(s"Cannot copy a directory to itself: src=$src, dst=$dst")))
    } else if (src.isRegularFile && dst.isDirectory) {
      // Special handling - plain file to directory copy
      Try(src.copyToDirectory(dst)(copyOptions = File.CopyOptions(overwrite = true))).toTaskResult(this)
    } else {
      Try(src.copyTo(dst, overwrite = true)).toTaskResult(this)
    }
  }

  override def rollBack(ctx: TaskExecution): TaskResult = {
    ctx.warn(s"Roll-back for $this task is not supported")
    Skipped(this)
  }
}

case class ModeTask(dst: Path, mode: FileMode) extends Task {

  override val name: String = s"Mode($dst -> ${mode.mask.toOctalString})"

  override def isDone(ctx: TaskExecution): Boolean = {
    val target = asFile(dst, ctx)
    target.exists && target.permissions == mode.permissions
  }

  override def perform(ctx: TaskExecution): TaskResult = {
    Try(asFile(dst, ctx).setPermissions(mode.permissions)).toTaskResult(this)
  }

  override def rollBack(ctx: TaskExecution): TaskResult = {
    ctx.warn(s"Roll-back for $this task is not supported")
    Skipped(this)
  }
}
