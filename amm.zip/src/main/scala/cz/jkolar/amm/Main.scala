package cz.jkolar.amm

object Main {

  def main(args: Array[String]): Unit = {
    println("Hello")
  }

  val z = "ZIZIZI"

}
