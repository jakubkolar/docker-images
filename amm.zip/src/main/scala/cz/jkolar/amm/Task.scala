package cz.jkolar.amm

import better.files.File

import scala.collection.immutable.Seq
import scala.util.{Failure, Success, Try}

trait Task {

  def name: String

  def isDone(ctx: TaskExecution): Boolean

  def perform(ctx: TaskExecution): TaskResult

  def rollBack(ctx: TaskExecution): TaskResult
}

sealed trait TaskResult {
  def task: Task
  def subResults: Seq[TaskResult]

  override def toString: String = {
    getClass.getSimpleName + "(" + task.name +
      subResults.foldLeft(": ")((s,tr) => s + s"${tr.task.name}->${tr.getClass.getSimpleName}") +
      ")"
  }
}

object TaskResult {

  def apply(task: Task, subResults: Seq[TaskResult]): TaskResult = {
    subResults.find(_.isInstanceOf[Failed]) match {
      case Some(Failed(_, e, _)) => Failed(task, e, subResults)
      case None => Done(task, subResults.toVector)
      case _ => sys.error("Unreachable code - maybe a missing case?")
    }
  }

  implicit class TryExtension(res: Try[Any]) {
    def toTaskResult(task: Task): TaskResult = {
      res match {
        case Success(_) => Done(task)
        case Failure(e) => Failed(task, Some(e))
      }
    }
  }
}

case class Done(task: Task, subResults: Seq[TaskResult] = Seq()) extends TaskResult
case class Skipped(task: Task, subResults: Seq[TaskResult] = Seq()) extends TaskResult
case class RolledBack(task: Task, subResults: Seq[TaskResult] = Seq()) extends TaskResult
case class Failed(task: Task, e: Option[Throwable] = None, subResults: Seq[TaskResult] = Seq()) extends TaskResult


abstract class CompositeTask extends Task {

  def steps: Seq[Task]

  override def name: String = toString

  override def isDone(ctx: TaskExecution): Boolean = {
    steps.forall(_.isDone(ctx))
  }

  override def perform(ctx: TaskExecution): TaskResult = {
    TaskResult(this, steps.map(_.perform(ctx)))
  }

  override def rollBack(ctx: TaskExecution): TaskResult = {
    TaskResult(this, steps.reverse.map(_.rollBack(ctx)))
  }

}

object CompositeTask {
  def apply(tasks: Task*): CompositeTask = {
    new CompositeTask{
      override val steps: Seq[Task] = tasks.toVector
    }
  }
}

trait TaskExecution {

  def workDir: File

  def run(task: Task): TaskResult

  def debug(msg: String): Unit
  def info(msg: String): Unit
  def warn(msg: String): Unit
  def error(msg: String): Unit
}

abstract class BaseExecution[P] extends TaskExecution {

  override def debug(msg: String): Unit = {}

  override def info(msg: String): Unit = {}

  override def warn(msg: String): Unit = {}

  override def error(msg: String): Unit = {}
}

class NaiveExecution[P](val params: P, val workDir: File) extends BaseExecution[P] {
  override def run(task: Task): TaskResult = {
    if (task.isDone(this)) Skipped(task) else task.perform(this)
  }
}

trait Logging extends TaskExecution {

  abstract override def run(task: Task): TaskResult = {
    info(s"Running task = $task")
    val result = super.run(task)
    info(s"Task $task finished with result $result")
    result
  }

  override def debug(msg: String): Unit = {
    println("[DEBUG] " + msg)
  }

  override def info(msg: String): Unit = {
    println("[INFO] " + msg)
  }

  override def warn(msg: String): Unit = {
    println("[WARN] " + msg)
  }

  override def error(msg: String): Unit = {
    println("[ERROR] " + msg)
  }
}
